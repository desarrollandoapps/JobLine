<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PayController extends Controller
{
    
    public function documento($id)
    {
        $API_ENDPOINT_TOKEN = 'http://35.224.231.248:98/api/Login/AuthWeb';
        $API_ENDPOINT_DOC = "http://35.224.231.248:98/api/Documento/";

        $token = Http::post($API_ENDPOINT_TOKEN);
        $documento = Http::withToken($token)->get($API_ENDPOINT_DOC . $id);


        //Firma: ApiKey~merchantId~referenceCode~amount~currency
        $ApiKey = '4Vj8eK4rloUd272L48hsrarnUA';
        $merchantId = '508029';
        $referenceCode = 'CM1-' . $documento['numero'];
        $firma = md5($ApiKey . '~' . $merchantId . '~' . $referenceCode . '~' . $documento['vrTotal'] . '~COP');

        return view('welcome', compact('documento', 'firma'));
    }

    public function response()
    {
        return view('response');
    }
}
