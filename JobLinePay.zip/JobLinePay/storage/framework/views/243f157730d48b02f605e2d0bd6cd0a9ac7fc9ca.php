<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <title>JobLine Pay</title>
</head>
<body>

    <nav class="navbar navbar-expand-md navbar-dark primary shadow">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('img/nav/logo-white.png')); ?>" alt="Logo" class="logo">
        </a> 
    </nav>
    
    <?php echo $__env->yieldContent('contenido'); ?>
    
    <footer class="mt-3">
        <div>
            <div class="row">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="titulo">Descarga la App</h1>
                        <br>
                        <a href="https://play.google.com/store/apps/details?id=com.appinc.jobline"  class="btn btn-primary text-white btn-title rounded-pill px-4 btn-principal" target="_blank">JobLineFree</a>
                        <br><br><br><br>
                    </div>
                </div>
                <div class="container">
                    <div class="row columnas-footer">
                        <div class="col-sm-12 col-md-7 col-lg-8 address">
                            <div class="d-flex align-items-center">
                                <div class="mr-3 d-none d-md-block">
                                    <img src="<?php echo e(asset('img/nav/logo-white.png')); ?>" class="img-fluid logo" alt="Logo">
                                </div>
                                <div>
                                    <p>
                                        Líneas móviles: 
                                        <a href="tel:3203334245">
                                            <b>320 333 4245</b>
                                        </a> 
                                        - 
                                        <a href="tel:3134339988" style="margin-right: 20px;">
                                            <b>313 433 9988</b>
                                        </a>
                                    </p>
                                    <ul class="nav nav-pills">
                                        <li><a href="tel:+573203334245">Ibagué: <b>+57 320 333 4245</b></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5 col-lg-4 text-center news">
                            <h5>• Recibe todas las Novedades •</h5>
                            <button (click)="abrirModal()" class="btn btn-primary text-white rounded-pill px-4 negro">Click aquí</button>
                        </div>
    
                    </div>
                </div>
            </div>
    
        </div>
        
        <hr>
        <div class="footer-pie">
            <div class="container">
                <p>Copyright &copy; 2020 JobLine</p>
            </div>
        </div>
    
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/JobLinePay/resources/views/layouts/layout.blade.php ENDPATH**/ ?>