@extends('layouts.layout')
@section('contenido')
    <h2 class="text-center mt-4">Resúmen de Pago</h2>

    <div class="container mt-5">
        <div class="row justify-content-md-center">
            <table class="table table-bordered col-sm-4">
                <tbody>
                    <tr>
                        <td class="font-weight-bold">Nombre</td>
                        <td>{{$documento['nombreCli']}}</td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold">Valor a pagar</td>
                        <td>${{number_format($documento['vrTotal'], 2, ',', '.')}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <form action="https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu" method="post" class="mx-auto formulario mt-5">
        <input name="merchantId"        type="hidden"  value="508029">
        <input name="accountId"         type="hidden"  value="512321">
        <input name="description"       type="hidden"  value="Compra de productos">
        <input name="referenceCode"     type="hidden"  value="CM1-{{$documento['numero']}}">
        <input name="amount"            type="hidden"  value="{{$documento['vrTotal']}}">
        <input name="tax"               type="hidden"  value="0">
        <input name="taxReturnBase"     type="hidden"  value="0">
        <input name="currency"          type="hidden"  value="COP">
        <input name="signature"         type="hidden"  value="{{$firma}}">
        <input name="test"              type="hidden"  value="1">
        <input name="payerFullName"     type="hidden"  value="APPROVED">
        <input name="buyerFullName"     type="hidden"  value="{{$documento['nombreCli']}}">
        <input name="buyerEmail"        type="hidden"  value="{{$documento['email']}}">
        <input name="shippingAddress"   type="hidden"  value="{{$documento['direccion']}}">
        <input name="shippingCity"      type="hidden"  value="{{$documento['ciudadId']}}">
        <input name="shippingCountry"   type="hidden"  value="CO">
        <input name="telephone"         type="hidden"  value="{{$documento['telefono']}}">
        <input name="responseUrl"       type="hidden"  value="http://appincdevs.com/ResponsePayu.php"> <!--CAMBIAR POR http://dominio/response-->
        <input name="Submit"            type="submit"  value="Confirmar pago"  class="btn btn-principal btn-block">
    </form>
@endsection